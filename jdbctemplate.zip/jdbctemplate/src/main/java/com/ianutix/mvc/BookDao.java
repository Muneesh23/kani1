package com.ianutix.mvc;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.inautix.book.Book;
import com.inautix.book.BookRowMapper;

@Component
public class BookDao extends JdbcDaoSupport {
	
	@Autowired
	public BookDao(DataSource datasource)
	{
		setDataSource(datasource);
	}
	
	public BookDao() {
		// TODO Auto-generated constructor stub
	}

	public ArrayList<Book> getBookDetails()
	{
		//String query="Select * from XBBNHBL_BOOK";
		ArrayList<Book> b=null;
		b= (ArrayList<Book>) getJdbcTemplate().query("Select * from XBBNHBL_BOOK", new Object[]{},new BookRowMapper());
	    return b;
	}

}
