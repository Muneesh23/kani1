package com.ianutix.mvc;

import java.util.ArrayList;
import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;


import com.inautix.book.Book;

public class BookController {
	@Autowired
	 BookDao dao;
	public void details()
	{
		
		ArrayList<Book> list=null;
		list=dao.getBookDetails();
		Iterator<Book> itr=list.iterator();
		while(itr.hasNext())
		{
			Book b=itr.next();
			System.out.println("Book:"+b.getId()+" "+b.getBookName()+" "+b.getAuthor() );
		}
		
		
	}
	


}
