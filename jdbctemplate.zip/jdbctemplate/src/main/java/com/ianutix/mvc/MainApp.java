package com.ianutix.mvc;

public class MainApp {

	public static void main(String[] args)
	{
		BookDao dao=new BookDao();
		dao.getBookDetails();
		
	}
}
