package com.inautix.book;



import java.util.ArrayList;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;
@Component
public class BookDetailsDao extends JdbcDaoSupport {

	@Autowired
public BookDetailsDao(DataSource datasource)
{
	setDataSource(datasource);
}

	
	public int createBookDetails(Book b)
	{
	
		String query="Insert into XBBNHBL_Book values('"+b.getId()+"','"+b.getBookName()+"','"+b.getAuthor()+"')";
		//String query="Insert into XBBNHBL_BOOK values(1,'twilight','stephine Mayor')";
		return getJdbcTemplate().update(query);
		//return jdbcTemplate.update(query);
		
	}
	
	public ArrayList<Book> getBookDetailsID(int id)
	{
		String query="select * from XBBNHBL_BOOK where Id='"+id+"'";
		ArrayList<Book> b=null;
		b=(ArrayList<Book>) getJdbcTemplate().query("select * from XBBNHBL_BOOK where Id="+id, new Object[]{},new BookRowMapper());
		return b;
	}
	
	public int  updateBookDetails(int id,String name,String author)
	{
		String query="Update XBBNHBL_BOOK set BookName='"+name+"',Author='"+author+"' where Id='"+id+"'";
		return getJdbcTemplate().update(query);
	}
	
	public int deleteBookDetails(int id)
	{
		String query="Delete from XBBNHBL_BOOK where Id='"+id+"'";
		return getJdbcTemplate().update(query);
	}
	
	public ArrayList<Book> getBookDetails()
	{
		String query="Select * from XBBNHBL_BOOK";
		return (ArrayList<Book>) getJdbcTemplate().query(query, new Object[]{},new BookRowMapper());
	}

}
