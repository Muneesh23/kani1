package com.inautix.book;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class BookDetailsController {
		@Autowired
		BookDetailsDao dao;

		@RequestMapping(value="/tests",method=RequestMethod.PUT)
		public int insertEmployee(){
			Book b=new Book(1,"harry potter","JK Rowling");
			int val=dao.createBookDetails(b);
			return val;
			//System.out.println(val);
		}
	
		@RequestMapping(value="/tests/{id}",method=RequestMethod.GET)
		public ArrayList<Book> getEmployeeDetails(@PathVariable(value="id")int eid){
			ArrayList<Book> eb=null;
			/*		System.out.println(eid);*/
			eb=dao.getBookDetailsID(eid);
			return eb;
		}
		
		@RequestMapping(value="/tests/{id}/{name}/{author}",method=RequestMethod.PUT)
		public int updateBookDetails(@PathVariable(value="id")int id,@PathVariable(value="name")String name,@PathVariable(value="author")String author)
		{
			int val=dao.updateBookDetails(id, name, author);
			return val;
		}
		
		
		@RequestMapping(value="/tests/{id}", method=RequestMethod.DELETE)
		public int deleteBookDetails(@PathVariable(value="id")int id)
		{
			int val=dao.deleteBookDetails(id);
			return val;
		}
	 
		@RequestMapping(value="/tests/all",method=RequestMethod.POST)
		public ArrayList<Book> getEmployeeDetails()
		{
			ArrayList<Book> b=null;
			b=dao.getBookDetails();
			return b;
		}

}
