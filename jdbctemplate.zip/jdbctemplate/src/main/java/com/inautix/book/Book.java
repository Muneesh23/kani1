package com.inautix.book;

public class Book {
	 public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookName(String bookName) {
		BookName = bookName;
	}
	public String getAuthor() {
		return Author;
	}
	public void setAuthor(String author) {
		Author = author;
	}
	int Id;    
	String BookName;
	String Author;
    
	public Book()
	{
		
	}
	public Book(int num,String name,String author)
	{
		this.Id=num;
		this.BookName=name;
		this.Author=author;
	}

}
