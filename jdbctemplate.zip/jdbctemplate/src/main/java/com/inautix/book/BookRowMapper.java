package com.inautix.book;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class BookRowMapper implements RowMapper<Book>{
	
	public Book mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Book b = new Book();
	    b.setId(rs.getInt(1));
	    b.setBookName(rs.getString(2));
	    b.setAuthor(rs.getString(3));
		return b;
	}

}
