CREATE TABLE XBBNHBL_Book(Id int,Bookname varchar(100),Author varchar(100))
Insert into XBBNHBL_BOOK values(1,'twilight','stephine Mayor')
select *from XBBNHBL_Book;