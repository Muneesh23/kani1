package com.inautix.office;

public class AttendenceInfoBean {
	

}
