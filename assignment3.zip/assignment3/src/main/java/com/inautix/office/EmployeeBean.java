package com.inautix.office;

public class EmployeeBean {
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	int Id;
	String grade;
	String employeeName;
}
