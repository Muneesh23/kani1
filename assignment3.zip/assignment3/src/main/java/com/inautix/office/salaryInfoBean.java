package com.inautix.office;

public class salaryInfoBean {
  public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
String grade;
  int salary;
  
  public int getSalaryforGrade(String grade) 
  {
	  if(grade.equals("A"))
	  {
		  return 10000;
	  }
	  else 
	  {
		  return 20000;
	  }
  }
}
