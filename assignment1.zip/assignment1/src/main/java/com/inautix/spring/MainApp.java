package com.inautix.spring;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.inautix.restraunt.Restraunt;

public class MainApp {
	
	 public static void main(String[] args) 
	 {
	  //Triangle triangle = new Triangle();
	      BeanFactory factory = new XmlBeanFactory(new FileSystemResource("src/main/webapp/WEB-INF/Spring.xml"));
	      Organizer org=(Organizer)factory.getBean("organizer");
	      org.sayGreetings();
	      System.out.println("Assignment1");
	      Restraunt res=(Restraunt)factory.getBean("restraunt");
	      res.getGroceries();
	      res.getvegetables();

	 }

}
