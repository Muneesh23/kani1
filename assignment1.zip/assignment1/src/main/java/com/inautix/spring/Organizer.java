package com.inautix.spring;

public class Organizer {
	
	public void sayGreetings()
	{
		System.out.println("Welcome to the talent Competition");
	}
	
	public void init()
	{
		System.out.println("Organizer Bean invoked...");
	}
	
	public void destroy()
	{
		System.out.println("Organizer Bean Destroyed");
	}

}
