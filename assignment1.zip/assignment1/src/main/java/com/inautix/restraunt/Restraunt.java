package com.inautix.restraunt;

public class Restraunt {
	private GroceryBean grocerybean;
	public GroceryBean getGrocerybean() {
		return grocerybean;
	}
	public void setGrocerybean(GroceryBean grocerybean) {
		this.grocerybean = grocerybean;
	}
	public VegetableBean getVegetablebean() {
		return vegetablebean;
	}
	public void setVegetablebean(VegetableBean vegetablebean) {
		this.vegetablebean = vegetablebean;
	}
	private VegetableBean vegetablebean;
	
	public Restraunt(GroceryBean grocerybean,VegetableBean vegetablebean)
	{
		this.grocerybean=grocerybean;
		this.vegetablebean=vegetablebean;
	}
	
	
	public void getGroceries() 
	{
		grocerybean.supplyGroceries();
	}
	public void getvegetables()
	{
		vegetablebean.supplyVegetables();
	}

}
