package com.inautix.restraunt;

public class VegetableBean {

	public void supplyVegetables()
	{
		System.out.println("Vegetables  supplied");
	}
}
