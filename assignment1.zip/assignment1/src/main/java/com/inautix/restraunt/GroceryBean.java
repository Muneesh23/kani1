package com.inautix.restraunt;

public class GroceryBean {
	
	public void supplyGroceries()
	{
		System.out.println("Groceries supplied");
	}

}
