package com.inautix.competition;

public interface Instrument {
	
	public void play();

}
