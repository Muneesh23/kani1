package com.inautix.competition;

public class SingerBean implements Performer{
	
	String song;
	public String getSong() {
		return song;
	}
	public void setSong(String song) {
		this.song = song;
	}
	public void perform()
	{
		//SingerBean sb=new SingerBean();
		System.out.println("Song Specified:"+getSong());
	}

}
