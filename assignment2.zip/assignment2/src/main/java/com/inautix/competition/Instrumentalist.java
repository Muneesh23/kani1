package com.inautix.competition;

public class Instrumentalist implements Performer {
	private SaxophoneBean saxophone;
	
	public SaxophoneBean getSaxophone() {
		return saxophone;
	}

	public void setSaxophone(SaxophoneBean saxophone) {
		this.saxophone = saxophone;
	}

	public void perform()
	{
		SaxophoneBean sb=new SaxophoneBean();
		sb.play();
	}
	

}
