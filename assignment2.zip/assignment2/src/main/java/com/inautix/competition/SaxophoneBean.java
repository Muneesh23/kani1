package com.inautix.competition;

public class SaxophoneBean implements Instrument {

 public void play()
 {
	 System.out.println("tu tu tu");
 }
}
