package com.inautix.competition;

public interface Performer {
	public void perform();


}
