package com.inautix.competition;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class PerformenceDemo {
	public static void main(String[] args)
	{
	  BeanFactory factory = new XmlBeanFactory(new FileSystemResource("src/main/webapp/WEB-INF/Spring.xml"));
	   System.out.println("**************Assignment2 a**************");
	   SingerBean sb=(SingerBean)factory.getBean("singer");
	   sb.perform();
	   System.out.println();
	   System.out.println("*************Assignment2 b***************");
	   Instrumentalist ins=(Instrumentalist)factory.getBean("instrumentalist");
	   ins.perform();
	   
	}  
}
