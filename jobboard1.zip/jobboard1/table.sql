CREATE SCHEMA Kanimozhi
SET SCHEMA Kanimozhi


CREATE TABLE T_XBBNHBL_POSTER(PosterNo int,seekerId varchar(20),employerId varchar(20),specialization varchar(20),selectionstatus varchar(20),acceptstatus varchar(20));
INSERT into T_XBBNHBL_POSTER values(1,'seeker01','employer01','game','selected','notaccepted');
INSERT into T_XBBNHBL_POSTER values(2,'seeker02','employer02','game','notselected')
INSERT into T_XBBNHBL_POSTER values(3,'seeker05','employer01','game','selected','notselected');
SELECT *FROM T_XBBNHBL_POSTER;
DELETE FROM T_XBBNHBL_POSTER where seekerId='seeker1'
DROP TABLE T_XBBNHBL_POSTER;

CREATE TABLE T_XBBNHBL_SEEKER(seekerId varchar(20),seekerName varchar(20),seekerDob varchar(10),seekerMail varchar(50),seekerPhone bigint,seekerAddress varchar(50),specialization varchar(50));
INSERT INTO  T_XBBNHBL_SEEKER values('seeker01','kani','09/03/2002','kani@gmail.com',9876543210,'madurai','game');
select *from T_XBBNHBL_SEEKER;
UPDATE T_XBBNHBL_SEEKER set seekerMail='nandy@gmail.com' where seekerId='seeker01';
DELETE FROM T_XBBNHBL_SEEKER where seekerId='seeker01';
DROP TABLE T_XBBNHBL_SEEKER;

CREATE TABLE T_XBBNHBL_POSTERAPP(seekerId varchar(20),)

CREATE TABLE T_XBBNHBL_CREDENTIAL(email varchar(50),password varchar(50),type varchar(10));
INSERT INTO T_XBBNHBL_CREDENTIAL values('kani@gmail.com','kani','seeker');
DELETE FROM T_XBBNHBL_CREDENTIAL where email='naveena@mail.com';
UPDATE T_XBBNHBL_CREDENTIAL set type='employer' where email='kani@gmail.com';
SELECT *FROM T_XBBNHBL_CREDENTIAL;
DROP TABLE T_XBBNHBL_CREDENTIAL;


CREATE TABLE T_XBBNHBL_EMPLOYER(employerId varchar(20),employerName varchar(30),employerMail varchar(50),empoyerPhone int,employerAddress varchar(50),office varchar(50));
INSERT INTO T_XBBNHBL_EMPLOYER values('employer01','anuja','anuja@gmail.com',1234567898,'madurai','inautix');
SELECT * FROM T_XBBNHBL_EMPLOYER;
DROP TABLE T_XBBNHBL_EMPLOYER;



CREATE TABLE T_XBBNHBL_APPLICATION(seekerId varchar(20),percent_10 varchar(10),percent_12 varchar(10),cgpa varchar(10),degree varchar(5),college varchar(50),domain varchar(40));
INSERT INTO T_XBBNHBL_APPLICATION values('seeker01','90.0','94.6','9.17','B.E','Mepco','game');
select *from T_XBBNHBL_APPLICATION;
DELETE from T_XBBNHBL_APPLICATION where percent_10='96';
DROP TABLE T_XBBNHBL_APPLICATION;
DELETE FROM T_XBBNHBL_APPLICATION where seekerId='seeker05';

CREATE TABLE T_XBBNHBL_JOBOFFER(employerMail varchar(50),seekerMail varchar(50),fromdate varchar(20),todate varchar(20),amount int,description varchar(200));
INSERT INTO T_XBBNHBL_JOBOFFER values('janani@gmail.com','20/02/2017','20/03/2017',2000,'Web Designing');
SELECT *FROM T_XBBNHBL_JOBOFFER;
DROP TABLE T_XBBNHBL_JOBOFFER;
DELETE FROM T_XBBNHBL_JOBOFFER where seekerMail='kani@gmail.com';









