/**
 * 
 */

function validate()
{
	
	var name=document.getElementById("name").value;
	var password=document.getElementById("password").value;
	var cpassword=document.getElementById("cpassword").value;
	var address=document.getElementById("address").value;
    var flag=0;
   // alert(name);
    alert(address);
	if(check(name,password,cpassword))
    {
	  if(alphanumeric(name))
	  {
		 if(alphanumeric(address))
	    {
	     if(password!=cpassword)
	    	{
	    	 //password.focus();
	    	alert("passwords do not match!!")
	    	}
	    else
	    {
	    	alert("Success");
	    }
	    }
	  }
	}
}
function alpha()
{ 
	//alert("alert inside alphanumeric!!!");
	var uadd=dopcument.getElementById("address");
	alert(uadd);
var letters = /^[0-9a-zA-Z]+$/;
if(uadd.value=="")
	{
	alert("Name Field Must not be Empty!!!");
	return false;
	}
else if(uadd.value.match(letters))
{
return true;
}
else
{
alert('User value must have alphanumeric characters only');
//uadd.focus();
return false;
}
}

function matchPassword()
{
	var pass=document.getElementById("password").value;
	var cpass=document.getElementById("cpassword").value;
	if(pass=="" || cpass=="")
		{
		  alert("Passwords Cannot be empty!!!");
		}
	if(pass!=cpass)
		{
		alert("Passwords should match!!!");
		return false;
		}
	else
		{
		return true;
		}
}

function alphanumeric(uadd)
{ 
	alert("alert inside alpha!!!");
var letters = /^[0-9a-zA-Z]+$/;
if(uadd.value.match(letters))
{
return true;
}
else
{
alert('User value must have alphanumeric characters only');
//uadd.focus();
return false;
}
}
function check(name,password,address)
{
	alert("alert inside check!!!");
	if(name=="")
	{
	  alert("Name Field Cannot be empty!!!");	
		return false;
	}
	else if(password=="")
	{
		alert("password required!!!");
		return false;
		
	}
	else if(address=="")
		{
		alert("Address required!!!");
		return false;
		
		}
	else
		{
		 return true;
		}
	}



function allLetter()
{ 
	//alert("Welcome");	
	 var uname=document.getElementById("name");
var letters = /^[A-Za-z]+$/;
if(uname.value=="")
{
alert("Name Field Must not be Empty!!!");
return false;
}
else if(uname.value.match(letters))
{
return true;
}
else
{
alert("Username must have alphabet characters only");
//uname.focus();
return false;
}
}


function checkphone()
{
    var phone=document.getElementById("number");
    var num=/^[0-9]+$/;
    
    if(phone.value == "")
    	{
    	alert("Number must not be empty!!!");
         return false;
    	}
    else if(phone.value.match(num))
    	{
    	return true;
    	}
    else
    	{
    	//phone.focus();
    	alert("Phone number contain only numbers!!!");
    	
    	}
    
}