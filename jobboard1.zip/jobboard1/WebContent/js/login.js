/**
 * 
 */

function validate()
{
	var user=document.getElementById("user").value;
	var password=document.getElementById("password").value;
	if(user=="" || password=="")
		{
		alert("Feilds are empty!!!");
		return false;
		}
	else
		{
		return true;
		}
}

function loginvalidate()
{
	window.location.href="seekerHomePage.html";
	alert("welcome");
	var user=document.getElementById("user").value;
	//alert(user);
	var seek="seeker01";
	var val=100;
	//var password=document.getElementById("password").value;
	if(user == "seeker01")
		{
		 window.location.href="seekerHomePage.html";
		}
	else 
		{
		
		wimdow.location.href="employerHomePage.html";
		}
}