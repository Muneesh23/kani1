/**
 * 
 */
$("#login").hover(function() {
	$("#login-form").slideToggle();
});