package com.inautix.jobboard;

public class Employerbean {

	public String getEmployerName() {
		return employerName;
	}
	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}
	public String getEmployerMail() {
		return employerMail;
	}
	public void setEmployerMail(String employerMail) {
		this.employerMail = employerMail;
	}
	public int getEmployerPhone() {
		return employerPhone;
	}
	public void setEmployerPhone(int employerPhone) {
		this.employerPhone = employerPhone;
	}
	public String getEmployerAddress() {
		return employerAddress;
	}
	public void setEmployerAddress(String employerAddress) {
		this.employerAddress = employerAddress;
	}
	public String getOffice() {
		return office;
	}
	public void setOffice(String office) {
		this.office = office;
	}
     
	public Employerbean(String name,String mail,int ph,String address,String office)
	{
		this.employerName = name;
		this.employerMail = mail;
		this.employerPhone = ph;
		this.employerAddress = address;
		this.office = office;
	}
	public Employerbean()
	{
		
	}
	
	String employerName;
	String employerMail;
	int employerPhone;
	String employerAddress;
	String office;

}
