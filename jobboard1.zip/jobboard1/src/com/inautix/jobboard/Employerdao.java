package com.inautix.jobboard;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;




public class Employerdao {
	
	//Code to employer SignUp
	public int InsertValues(String id,String name,String mail,int num,String address,String office)
	{
		int val=0;
		Connection con = ConnectionManager.getConnection();
		Statement stmt=null;
		String query="INSERT into T_XBBNHBL_EMPLOYER values('"+id+"','"+name+"','"+mail+"',"+num+",'"+address+"','"+office+"')";
		try {
			 stmt=con.createStatement();
			 val=stmt.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(val>=1)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	//code to search for the JOB SEEKERS Based on the specialization
	
	public static List<Employerbean> getHoldings(){
		// create statement object 
				Connection con = ConnectionManager.getConnection();
				List<Employerbean> holdingsList = null;
				ResultSet resultset = null;
				Statement stmt=null;
				
				String Query = "SELECT *  from T_XBBNHBL_EMPLOYER";
				try {
					 stmt=con.createStatement();
					 resultset = stmt.executeQuery(Query);	
						
					 holdingsList = new ArrayList<Employerbean>();
					 while(resultset.next())
					 {
						 Employerbean employerBean=new Employerbean();
						 //employerBean.setEmployerId(resultset.getString(1));
						 employerBean.setEmployerName(resultset.getString(2));
						 employerBean.setEmployerMail(resultset.getString(3));
						 employerBean.setEmployerPhone(resultset.getInt(4));
						 employerBean.setEmployerAddress(resultset.getString(5));
						 employerBean.setOffice(resultset.getString(6));
						 holdingsList.add(employerBean);
						 
					 }
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally
				{
					try {
						resultset.close();
						stmt.close();
						con.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				return holdingsList;
	}
	
	
	
	//code to update tables when employer selects the seeker
	
	
	public int Update(String seekerID)
	{
		int val=0;
		Connection con = ConnectionManager.getConnection();
		String query="Update T_XBBNHBL_POSTER set status='selected' WHERE seekerId='"+seekerID+"'";
		Statement stmt=null;
		try {
			stmt=con.createStatement();
			val=stmt.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(val>=1)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	
	}
	
	
	//code to provide details to the job seeker about the job expected
	
	public int provideDetails(String id,String fromdate,String todate,int amount,String description)
	{
		int val=0;
		Connection con = ConnectionManager.getConnection();
		Statement stmt=null;
		String query="INSERT into T_XBBNHBL_JOBOFFER values('"+id+"','"+fromdate+"','"+todate+"','"+amount+"','"+description+"')";
		try {
			 stmt=con.createStatement();
			 val=stmt.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(val>=1)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

}
