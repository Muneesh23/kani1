																						package com.inautix.jobboard;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class SeekerDao {
	public static List<SeekerBean> getHoldings(){
	// create statement object 
			Connection con = ConnectionManager.getConnection();
			List<SeekerBean> holdingsList = null;
			ResultSet resultset = null;
			Statement stmt=null;
			
			String Query = "SELECT *  from T_XBBNHBL_SEEKER";
			try {
				 stmt=con.createStatement();
				 resultset = stmt.executeQuery(Query);	
					
				 holdingsList = new ArrayList<SeekerBean>();
				 while(resultset.next())
				 {
					 SeekerBean SeekerBean=new SeekerBean();
					 //SeekerBean.setSeekerId(resultset.getString(1));
					 SeekerBean.setSeekerName(resultset.getString(2));
					 SeekerBean.setSeekerMail(resultset.getString(4));
					 SeekerBean.setSeekerPhone(resultset.getLong(5));
					 SeekerBean.setSeekerDob(resultset.getString(3));
					 SeekerBean.setSeekerAddress(resultset.getString(6));
					 SeekerBean.setSpecialization(resultset.getString(7));
					 holdingsList.add(SeekerBean);
					 
				 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				try {
					resultset.close();
					stmt.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return holdingsList;
}
	
	//public int Insert(String PosterId,String SeekerId,String EmployerId,String Specialization,String PosterNo)
	public int Insert()
	{
		int val=0;
		Connection con = ConnectionManager.getConnection();
		Statement stmt=null;
		String query="INSERT into T_XBBNHBL_POSTER values('Poster04','Software','Seeker04','Employer04','4')";
		try {
			 stmt=con.createStatement();
			 val=stmt.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(val>=1)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	public int Delete(String seekerId)
	{
		int val=0;
		
		Scanner in=new Scanner(System.in);
		//System.out.println("Enter seeker ID");
		//seekerId=in.next();
		Connection con = ConnectionManager.getConnection();
		String query="Delete From T_XBBNHBL_SEEKER where seekerId='"+seekerId+"'";
		Statement stmt=null;
		try {
			stmt = con.createStatement();
			val=stmt.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				stmt.close();
				con.close();
				in.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(val>=1)
		{
			return 1;
		}
		else
		{
			return 0;
		}
		
	}
	public int Update(String PosterID)
	{
		int val=0;
		Connection con = ConnectionManager.getConnection();
		String query="Update T_XBBNHBL_POSTER set seekerId='seek01' WHERE posterId='"+PosterID+"'";
		Statement stmt=null;
		try {
			stmt=con.createStatement();
			val=stmt.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(val>=1)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	
	}
	
	
	
	
	
	//insert function with values from front end
	
	public int InsertValues(String id,String name,String dob,BigInteger num,String mail,String address,String special)
	{
		int val=0;
		Connection con = ConnectionManager.getConnection();
		Statement stmt=null;
		String query="INSERT into T_XBBNHBL_SEEKER values('"+id+"','"+name+"','"+dob+"','"+mail+"','"+num+"','"+address+"','"+special+"')";
		try {
			 stmt=con.createStatement();
			 val=stmt.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			
		}
		finally
		{
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
		}
		if(val>=1)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	//Insert using prepared statement
	public int InsertDynamic(String id,String name,String dob,int num,String mail,String address,String special)
	{
		Connection con=ConnectionManager.getConnection();
		PreparedStatement stmt;
	     String query="Insert into T_XBBNHBL_CREDENTIAL values('"+mail+"','"+mail+"')";
		int i=0;
		try {
			stmt = con.prepareStatement("insert into T_XBBNHBL_SEEKER values(?,?,?,?,?,?,?)");
			stmt.setString(1,id);//1 specifies the first parameter in the query  
			stmt.setString(2,name);
			stmt.setString(3, dob);
			stmt.setString(4, mail);
			stmt.setInt(5, num);
			stmt.setString(6, address);
			stmt.setString(7, special);
			  
			 i=stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		Statement stmt1;
		try {
			stmt1 = con.createStatement();
			stmt1.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	    
		return i;
	}
	
	public void viewOffers(String seekerId1)
	{
		ResultSet resultset=null;
	// 	ResultSet rs2=null;
	//  ResultSet rs1=null;
	//	String query1=null;
		Connection con=ConnectionManager.getConnection();
		String query="select em.employerId,off.fromdate,off.todate,off.amount,off.description from T_XBBNHBL_EMPLOYER em JOIN T_XBBNHBL_POSTER po ON em.employerId=po.employerId JOIN T_XBBNHBL_JOBOFFER off ON po.seekerId=off.seekerId where po.seekerId='"+seekerId1+"'";
		
		try {
			Statement stmt=con.createStatement();
			resultset=stmt.executeQuery(query);
			System.out.println("OFFERS PROVIDED!!!");
			while(resultset.next())
			{
			System.out.println("Employer ID:"+resultset.getString(1));
			System.out.println("FROM DATE:"+resultset.getString(2));
		    System.out.println("TO DATE:"+resultset.getString(3));
		    System.out.println("SALARY(Negotiable):"+resultset.getInt(4));
		    System.out.println("JOB DESCRIPTION:"+resultset.getString(5));
		    }
			/*while(resultset.next())
			{
			System.out.println("Employer ID:"+resultset.getString(2));
			 query1="select *from T_XBBNHBL_EMPLOYER where employerId='"+resultset.getString(2)+"'";
			}
			
		    rs1=stmt.executeQuery(query1);
		    while(rs1.next())
		    {
		    System.out.println("COMPANY NAME:"+ rs1.getString(4));
		    }
		    
		    String query2="select *from T_XBBNHBL_JOBOFFER where seekerId='"+seekerId1+"'";
		    rs2=stmt.executeQuery(query2);
		    while(rs2.next())
		    {
		    System.out.println("FROM DATE:"+rs2.getString(1));
		    System.out.println("TO DATE:"+rs2.getString(2));
		    System.out.println("SALARY(Negotiable):"+rs2.getInt(4));
		    System.out.println("JOB DESCRIPTION:"+rs2.getString(5));
		    }*/
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	//Code To allow the user to view his/her Profile
	
	public void viewProfile(String seekerId1)
	{
		ResultSet resultset=null;
	// 	ResultSet rs2=null;
	//  ResultSet rs1=null;
	//	String query1=null;
		Connection con=ConnectionManager.getConnection();
		String query="select percent_10,percent_12,cgpa,degree,college,domain from T_XBBNHBL_APPLICATION where seekerId='"+seekerId1+"'";
		
		try {
			Statement stmt=con.createStatement();
			resultset=stmt.executeQuery(query);
			System.out.println("PROFILE DETAILS:");
			while(resultset.next())
			{
			System.out.println("Percentage In 10th:"+resultset.getFloat(1));
			System.out.println("Percentage In 12th:"+resultset.getFloat(2));
		    System.out.println("Cgpa:"+resultset.getFloat(3));
		    System.out.println("Degree:"+resultset.getString(4));
		    System.out.println("College:"+resultset.getString(5));
		    System.out.println("Domain:"+resultset.getString(6));
		    }
			/*while(resultset.next())
			{
			System.out.println("Employer ID:"+resultset.getString(2));
			 query1="select *from T_XBBNHBL_EMPLOYER where employerId='"+resultset.getString(2)+"'";
			}
			
		    rs1=stmt.executeQuery(query1);
		    while(rs1.next())
		    {
		    System.out.println("COMPANY NAME:"+ rs1.getString(4));
		    }
		    
		    String query2="select *from T_XBBNHBL_JOBOFFER where seekerId='"+seekerId1+"'";
		    rs2=stmt.executeQuery(query2);
		    while(rs2.next())
		    {
		    System.out.println("FROM DATE:"+rs2.getString(1));
		    System.out.println("TO DATE:"+rs2.getString(2));
		    System.out.println("SALARY(Negotiable):"+rs2.getInt(4));
		    System.out.println("JOB DESCRIPTION:"+rs2.getString(5));
		    }*/
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
