package com.inautix.jobboard;

import java.io.IOException;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



/**
 * Servlet implementation class seekerSignUp
 */
@WebServlet("/seekerSignUp")
public class seekerSignUp extends HttpServlet {
	static int cnt=1;
	static int postcnt=1;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public seekerSignUp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		//response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session=request.getSession();
		String name=request.getParameter("name");
		String dob=request.getParameter("date");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String num=request.getParameter("number");
		BigInteger number = new BigInteger(num);
		
		String address=request.getParameter("address");
		String special=request.getParameter("special");
		//System.out.println(name+" "+dob+" "+email+" "+num+" "+address+" "+special);
		
		String id="seeker"+cnt;
		session.setAttribute("seekerId", id);
		int val=InsertValues(id,name,dob,number,email,address,special,password);
		
		if(val>=1 )
		{
			response.sendRedirect("elogin.jsp");
		}
		else
		{
			response.sendRedirect("SignUpError.jsp");
		}
		
	}
 
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	public int InsertValues(String id,String name,String dob,BigInteger num,String mail,String address,String special,String password)
	{
		cnt++;
		 Connection con=null;
			try {
				Class.forName("org.apache.derby.jdbc.ClientDriver");
				//Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample;create=true","kanimozhi","kanimozhi");
				//con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		int val=0,val1=0,val2=0;
		//Connection con = ConnectionManager.getConnection();
		Statement stmt=null;
		String query="INSERT into T_XBBNHBL_SEEKER values('"+id+"','"+name+"','"+dob+"','"+mail+"',"+num+",'"+address+"','"+special+"')";
		String query1="INSERT into T_XBBNHBL_CREDENTIAL values('"+mail+"','"+password+"','seeker')";
		String query2="Insert into T_XBBNHBL_POSTER values("+postcnt+",'"+id+"','','"+special+"','notselected','notaccepted')";
		postcnt++;
		try {
			 stmt=con.createStatement();
			 val=stmt.executeUpdate(query);
			 val1=stmt.executeUpdate(query1);
			 val2=stmt.executeUpdate(query2);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
		}
		if(val>=1 && val1>=1 && val2>=1)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
}
