package com.inautix.jobboard;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Loginapp {
	public static void main(String[] args)
	{
	  /* Logindao logindao=new Logindao();
	   int val=logindao.validate("nandy@mail.com","nandy@mail.com");
	   if(val==1)
	   {
		   System.out.println("VERIFICATION SUCCESS!!");
	   }
	   else
	   {
		   System.out.println("INCORRECT USER NAME OR PASSWORD");
	   }*/
		
		   ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		   SeekerBean se=(SeekerBean) context.getBean("seekerbean");
		   //se.validate();
		
	}

}
