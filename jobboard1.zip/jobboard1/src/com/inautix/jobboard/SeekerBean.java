package com.inautix.jobboard;

public class SeekerBean {
	
	private SeekerDao seekerdao;
	
	public SeekerDao getSeekerDao()
	{
		return this.seekerdao;
	}
	
	public void setSeekerDao(SeekerDao seekerDao)
	{
		this.seekerdao=seekerDao;
	}
	
	public SeekerBean(SeekerDao seekerdao)
	{
		this.seekerdao=seekerdao;
	}
	
	public int delete(String seeker)
	{
		int val=seekerdao.Delete(seeker);
		return val;
	}
	
	public SeekerBean()
	{
		
	}
	
	public String getSeekerName() {
		return seekerName;
	}
	public void setSeekerName(String seekerName) {
		this.seekerName = seekerName;
	}
	
	public String getSeekerDob() {
		return seekerDob;
	}
	public void setSeekerDob(String seekerDob) {
		this.seekerDob = seekerDob;
	}
	public long getSeekerPhone() {
		return seekerPhone;
	}
	public void setSeekerPhone(long l) {
		this.seekerPhone = l;
	}
	public String getSeekerMail() {
		return seekerMail;
	}
	public void setSeekerMail(String seekerMail) {
		this.seekerMail = seekerMail;
	}
	public String getSeekerAddress() {
		return seekerAddress;
	}
	public void setSeekerAddress(String seekerAddress) {
		this.seekerAddress = seekerAddress;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	String seekerName;
	String seekerDob;
	long seekerPhone;
	String seekerMail;
	String seekerAddress;
	String specialization;

}
