package com.inautix.jobboard;

import java.sql.*;


public class ConnectionManager {
   // static Connection con=null;
	 public static Connection getConnection()
	   {
		 Connection con=null;
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			//Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample","kanimozhi","kanimozhi");
			//con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return con;
	     
	   }

}
