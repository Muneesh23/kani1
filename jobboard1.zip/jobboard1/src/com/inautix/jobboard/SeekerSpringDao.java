package com.inautix.jobboard;
import org.springframework.jdbc.core.JdbcTemplate; 

public class SeekerSpringDao {
	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}
	
	public int updateEmployee(String name,String mail){  
	    String query="update T_XBBNHBL_SEEKER set seekerName='"+name+"' where SeekerMail='"+mail+"' ";  
	    return jdbcTemplate.update(query);  
	} 

}
