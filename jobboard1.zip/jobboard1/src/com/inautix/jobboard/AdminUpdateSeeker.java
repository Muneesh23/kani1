package com.inautix.jobboard;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import org.springframework.context.ApplicationContext;  
import org.springframework.context.support.ClassPathXmlApplicationContext;
/**
 * Servlet implementation class AdminUpdateSeeker
 */
@WebServlet("/AdminUpdateSeeker")
public class AdminUpdateSeeker extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminUpdateSeeker() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session=request.getSession();
		 ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");  
		 
		 SeekerSpringDao dao=(SeekerSpringDao) context.getBean("edao");
		 String name=request.getParameter("name");
		 String mail=request.getParameter("mail");
		 System.out.println(name);
		int status=dao.updateEmployee(name,mail);
		if(status>=1)
		{
			session.setAttribute("status","sucess");
			response.sendRedirect("AdminHomePage.jsp");
		}
		else
		{
			System.out.println("SignUpError.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
