package com.inautix.jobboard.login;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import com.inautix.jobboard.jobPoster.ConnectionManager;

public class Logindao {
	public int validate(String mail,String password)
	{
		int flag=0;
	Connection con = ConnectionManager.getConnection();
	Statement stmt=null;
	ResultSet resultset = null;
	String Query = "SELECT *  from T_XBBNHBL_CREDENTIAL";
	try {
		 stmt=con.createStatement();
		 resultset = stmt.executeQuery(Query);	
		 while(resultset.next())
		 {
			 System.out.println(resultset.getString(1)+resultset.getString(2)+password);
			 if(resultset.getString(2).equals(password))
			 {
			   flag=1;
			   break;
			 }
		 }
		 if(flag==1)
		 {
			 return 1;
		 }
		 else
		 {
			 return 0;
		 }
		 
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return 0;
	}
	}

}
