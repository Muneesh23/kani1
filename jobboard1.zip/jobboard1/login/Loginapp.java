package com.inautix.jobboard.login;

public class Loginapp {
	public static void main(String[] args)
	{
	   Logindao logindao=new Logindao();
	   int val=logindao.validate("nandy@mail.com","nandy@mail.com");
	   if(val==1)
	   {
		   System.out.println("VERIFICATION SUCCESS!!");
	   }
	   else
	   {
		   System.out.println("INCORRECT USER NAME OR PASSWORD");
	   }
	}

}
